"""OSMnx package version."""

__version__ = "1.1.2"
